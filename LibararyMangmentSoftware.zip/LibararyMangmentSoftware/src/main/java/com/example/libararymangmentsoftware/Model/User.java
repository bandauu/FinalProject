package com.example.libararymangmentsoftware.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class User {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Integer id;

    private String name;

    //@Max(value = 3 , message = "borrowed books mustn't be more than 3")
    private Integer no_of_borrowed_books; // condition
    //@Max(value = 3 , message = "returned books mustn't be more than 3")
    private Integer no_of_returned_books;

   // @Max(value = 1 , message = "reserved books mustn't be more than 1")
    private Integer no_of_reserved_books;





}
