package com.example.libararymangmentsoftware.Repositry;

import com.example.libararymangmentsoftware.Model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepositry extends JpaRepository<Book,Integer> {
//
  Book findBookByIsbn(Integer isbn);

  List<Book> findAllByAuthorName(String name);



  List<Book> findAllByUserId(Integer id);

  List<Book> findAllByStatus(String status);


}
