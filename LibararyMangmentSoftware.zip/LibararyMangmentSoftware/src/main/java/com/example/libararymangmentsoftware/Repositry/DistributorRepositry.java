package com.example.libararymangmentsoftware.Repositry;

import com.example.libararymangmentsoftware.Model.Distributor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DistributorRepositry extends JpaRepository<Distributor,Integer> {

    Distributor findDistributorById(Integer id);
}
