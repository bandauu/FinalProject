package com.example.libararymangmentsoftware.Controller;

import com.example.libararymangmentsoftware.ApiResponse;

import com.example.libararymangmentsoftware.Model.Distributor;
import com.example.libararymangmentsoftware.Service.DistributorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor")
@RequiredArgsConstructor
public class DistributorController {


    private final DistributorService distributorService;
    @GetMapping("/get")
    public ResponseEntity getDistributor(){
        List<Distributor> b = distributorService.getDistributor();
        return ResponseEntity.status(200).body(b);
    }

    @PostMapping("/add")
    public ResponseEntity addDistributor(@RequestBody @Valid Distributor d){
        distributorService.addDistributor(d);
        return ResponseEntity.status(201).body(new ApiResponse("Distributor added!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateDistributor(@PathVariable Integer id , @RequestBody @Valid Distributor d){
        distributorService.updateDistributor(id,d);
        return ResponseEntity.status(200).body(new ApiResponse("Distributor updated!"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteDistributor(@PathVariable Integer id ){
        distributorService.deleteDistributor(id);
        return ResponseEntity.status(200).body(new ApiResponse("Distributor deleted!"));
    }

    @GetMapping("/{id}")
    public ResponseEntity findDistributorById(@PathVariable Integer id){
        Distributor d = distributorService.findDistributorById(id);
        return ResponseEntity.status(200).body(d);
    }
}
