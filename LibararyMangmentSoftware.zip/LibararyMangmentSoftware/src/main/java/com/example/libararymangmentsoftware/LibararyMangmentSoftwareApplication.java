package com.example.libararymangmentsoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibararyMangmentSoftwareApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibararyMangmentSoftwareApplication.class, args);
    }

}
