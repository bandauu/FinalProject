package com.example.libararymangmentsoftware.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Negative;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Entity
@NoArgsConstructor
public class Book {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Integer isbn;

    private String title;

    private String authorName; // get by author name <

    private Integer distributorId; // get all books by this distributor id <

    private Integer userId; // get all books by this user id

    @Column(columnDefinition = "varchar(20) not null check (status='reserved' or status='returned' or status='borrowed')")
    private String status; // book status


}
