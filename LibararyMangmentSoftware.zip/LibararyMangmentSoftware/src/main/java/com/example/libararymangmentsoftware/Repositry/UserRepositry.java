package com.example.libararymangmentsoftware.Repositry;

import com.example.libararymangmentsoftware.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepositry extends JpaRepository<User,Integer> {
    User findUserById(Integer id);
}
