package com.example.libararymangmentsoftware.Service;

import com.example.libararymangmentsoftware.ApiException;
import com.example.libararymangmentsoftware.Model.Distributor;
import com.example.libararymangmentsoftware.Model.User;
import com.example.libararymangmentsoftware.Repositry.BookRepositry;
import com.example.libararymangmentsoftware.Repositry.DistributorRepositry;
import com.example.libararymangmentsoftware.Repositry.UserRepositry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.example.libararymangmentsoftware.Model.Book;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepositry book;
    private final UserRepositry userRepositry;
    private final DistributorRepositry distributorRepositry;


    public List<Book> getBook(){
        return book.findAll();
    }

    public void addBook(Book boo){
       User u= userRepositry.findUserById(boo.getUserId());
       Distributor d =distributorRepositry.findDistributorById((boo.getDistributorId()));
       if ( u == null || d == null){
           throw new ApiException("id for User or Distributor not found");
       }
        book.save(boo);
    }

    public void updateBook(Integer isbn , Book boo){
        Book oldbook = book.findBookByIsbn(isbn);
        if ( oldbook==null){
            throw new ApiException("wrong isbn");
        }
        oldbook.setTitle(boo.getTitle());
        oldbook.setAuthorName(boo.getAuthorName());
        oldbook.setStatus(boo.getStatus());
        oldbook.setUserId(boo.getUserId());
        oldbook.setDistributorId(boo.getDistributorId());
        book.save(oldbook);
    }

    public void deleteBook(Integer isbn){
        Book oldbook = book.findBookByIsbn(isbn);
        if ( oldbook==null){
            throw new ApiException("wrong id");
        }
        book.delete(oldbook);
    }


    public Book findBookByIsbn(Integer isbn){
      Book book1 = book.findBookByIsbn(isbn);
        if ( book1==null){
            throw new ApiException("wrong id");
        }
        return book1;
    }

    public List<Book> findAllByUserId(Integer id) {
        User user1 = userRepositry.findUserById(id);
        if (user1 == null) {
            throw  new ApiException("id not found!");
        } else {
            List<Book> books = book.findAllByUserId(id);
            return books;
        }
    }

//
//        public List<Book> findAllByDistributor_id(Integer id){
//            Distributor d = distributor.findDistributorById(id);
//            if (d == null) {
//                throw new ApiException("id not found!");
//            } else {
//                List<Book> books = book.findAllByDistributor_id(id);
//                return books;
//            }
//        }
//
        public List<Book> findAllByStatus(String status){
            List<Book> b = book.findAllByStatus(status);
            if (b == null) {
                throw new ApiException("no books under :" + status);
            }
            else{
                List<Book> books = book.findAllByStatus(status);
                return books;
            }
        }
//
//
        public List<Book> findAllByAuthorName(String name){
            List<Book> b = book.findAllByAuthorName(name);
            if (b == null) {
                throw new ApiException("no books under :" + name);
            }
            return b;
        }


}
