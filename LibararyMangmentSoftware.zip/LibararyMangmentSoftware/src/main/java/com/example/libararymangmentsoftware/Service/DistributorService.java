package com.example.libararymangmentsoftware.Service;

import com.example.libararymangmentsoftware.ApiException;
import com.example.libararymangmentsoftware.Model.Distributor;
import com.example.libararymangmentsoftware.Repositry.DistributorRepositry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor

public class DistributorService {

    private final DistributorRepositry distributor;

    public List<Distributor> getDistributor(){
        return distributor.findAll();
    }

    public void addDistributor(Distributor e){
        distributor.save(e);
    }

    public void updateDistributor(Integer id , Distributor e){
        Distributor oldDis = distributor.findDistributorById(id);
        if (oldDis==null){
            throw new ApiException("wrong id");
        }
        oldDis.setName(e.getName());
        distributor.save(oldDis);
    }

    public void deleteDistributor(Integer id ){
        Distributor oldDis = distributor.findDistributorById(id);
        if ( oldDis==null){
            throw new ApiException("wrong id");
        }
        distributor.delete(oldDis);
    }

    public Distributor findDistributorById(Integer id){
        Distributor d = distributor.findDistributorById(id);
        if ( d==null){
            throw new ApiException("wrong id");
        }
        return d;
    }
}
