package com.example.libararymangmentsoftware.Service;

import com.example.libararymangmentsoftware.ApiException;
import com.example.libararymangmentsoftware.Model.User;
import com.example.libararymangmentsoftware.Repositry.UserRepositry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepositry user;

    public List<User> getUser(){
        return user.findAll();
    }

    public void addUser(User u){
        user.save(u);
    }

    public void updateUser(Integer id , User e){
        User oldUser = user.findUserById(id);
        if (oldUser==null){
            throw new ApiException("wrong id");
        }
        oldUser.setName(e.getName());
        oldUser.setNo_of_borrowed_books(e.getNo_of_borrowed_books());
        oldUser.setNo_of_reserved_books(e.getNo_of_reserved_books());
        oldUser.setNo_of_returned_books(e.getNo_of_returned_books());
        user.save(oldUser);
    }

    public void deleteUser(Integer id ){
        User oldUser = user.findUserById(id);
        if (oldUser==null){
            throw new ApiException("wrong id");
        }
       user.delete(oldUser);
    }

    public User findUserById(Integer id){
        User user1 = user.findUserById(id);
        if (user1==null){
            throw new ApiException("wrong id");
        }
        return user1;
    }

}
