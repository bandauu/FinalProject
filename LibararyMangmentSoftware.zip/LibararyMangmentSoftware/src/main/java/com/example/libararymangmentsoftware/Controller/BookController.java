package com.example.libararymangmentsoftware.Controller;

import com.example.libararymangmentsoftware.ApiResponse;
import com.example.libararymangmentsoftware.Model.Book;
import com.example.libararymangmentsoftware.Service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/book")
@RequiredArgsConstructor
public class BookController {

    private final BookService book;
    @GetMapping("/get")
    public ResponseEntity getBook(){
        List<Book> b = book.getBook();
        return ResponseEntity.status(200).body(b);
    }

    @PostMapping("/add")
    public ResponseEntity addBook(@RequestBody Book b){
        book.addBook(b);
        return ResponseEntity.status(201).body(new ApiResponse("book added!"));
    }

    @PutMapping("/update/{isbn}")
    public ResponseEntity updateBook(@PathVariable Integer isbn , @RequestBody Book b){
        book.updateBook(isbn,b);
        return ResponseEntity.status(200).body(new ApiResponse("book updated!"));
    }

    @DeleteMapping("/delete/{isbn}")
    public ResponseEntity deleteBook(@PathVariable Integer isbn ){
        book.deleteBook(isbn);
        return ResponseEntity.status(200).body(new ApiResponse("book deleted!"));
    }

    @GetMapping("/getby/{isbn}")
    public ResponseEntity findBookByIsbn(@PathVariable Integer isbn ){
        Book b = book.findBookByIsbn(isbn);
        return ResponseEntity.status(200).body(b);
    }

   @GetMapping("/getuser/books/{id}")
    public ResponseEntity findAllByUserId(@PathVariable Integer id ){
        List<Book> b = book.findAllByUserId(id);
        return ResponseEntity.status(200).body(b);
    }

    @GetMapping("/getstatus/books/{status}")
    public ResponseEntity getBooksByStatus(@PathVariable String status ){
        List<Book> b = book.findAllByStatus(status);
        return ResponseEntity.status(200).body(b);
    }
//
    @GetMapping("/getauthor/books/{name}")
    public ResponseEntity getBooksByAuthor_name(@PathVariable String name){
        List<Book> b = book.findAllByAuthorName(name);
        return ResponseEntity.status(200).body(b);

    }

}
