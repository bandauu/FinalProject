package com.example.libararymangmentsoftware.Controller;

import com.example.libararymangmentsoftware.ApiResponse;
import com.example.libararymangmentsoftware.Service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.libararymangmentsoftware.Model.User;

import java.util.List;

@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userservice;

    @GetMapping("/get")
    public ResponseEntity getUser(){
       List<User> u = userservice.getUser();
       return ResponseEntity.status(200).body(u);
    }

    @PostMapping("/add")
    public ResponseEntity addUser(@RequestBody @Valid User u){
        userservice.addUser(u);
        return ResponseEntity.status(201).body(new ApiResponse("user added!"));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity updateUser(@PathVariable Integer id , @RequestBody @Valid User u){
        userservice.updateUser(id,u);
        return ResponseEntity.status(200).body(new ApiResponse("user updated!"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteUser(@PathVariable Integer id){
        userservice.deleteUser(id);
        return ResponseEntity.status(200).body(new ApiResponse("user deleted!"));
    }

    @GetMapping("/{id}")
    public ResponseEntity findUserById(@PathVariable Integer id){
        User u = userservice.findUserById(id);
        return ResponseEntity.status(200).body(u);
    }
}
