package com.example.libararymangmentsoftware.AdviceController;

import com.example.libararymangmentsoftware.ApiException;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
@RestControllerAdvice
public class Advice {

    @ExceptionHandler(value = ApiException.class)
    public ResponseEntity ApiException(ApiException object){ // method name must be same as exception
        String message = object.getMessage();
        return ResponseEntity.status(400).body(message);
    }
    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity ConstraintViolationException(ConstraintViolationException e){
        String message=e.getMessage();
        return ResponseEntity.status(400).body(message);
    }

}
